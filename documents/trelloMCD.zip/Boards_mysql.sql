CREATE DATABASE IF NOT EXISTS `BOARDS` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `BOARDS`;

CREATE TABLE `USERS` (
  `id_user(int)` VARCHAR(42),
  `email(varchar)` VARCHAR(42),
  `username(varchar)` VARCHAR(42),
  `password(varchar)` VARCHAR(42),
  `role(varchar)` VARCHAR(42),
  `created_at(datetime)` VARCHAR(42),
  `updated_at(datetime)` VARCHAR(42),
  PRIMARY KEY (`id_user(int)`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `HAVE_ACCESS` (
  `id_user(int)` VARCHAR(42),
  `id_board(int)` VARCHAR(42),
  PRIMARY KEY (`id_user(int`id_board(int)`)`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `BOARD` (
  `id_board(int)` VARCHAR(42),
  `title(varchar)` VARCHAR(42),
  `color(varchar)` VARCHAR(42),
  `owner_id(int)` VARCHAR(42),
  `created_at(datetime)` VARCHAR(42),
  `updated_at(datetime)` VARCHAR(42),
  PRIMARY KEY (`id_board(int)`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `LIST` (
  `id_list(int)` VARCHAR(42),
  `title(varchar)` VARCHAR(42),
  `color(varchar)` VARCHAR(42),
  `order(int)` VARCHAR(42),
  `board_id(int)` VARCHAR(42),
  `created_at(datetime)` VARCHAR(42),
  `updated_at(datetime)` VARCHAR(42),
  `id_board(int)` VARCHAR(42),
  PRIMARY KEY (`id_list(int)`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `CARD` (
  `id_card(int)` VARCHAR(42),
  `title(varchar)` VARCHAR(42),
  `content(varchar)` VARCHAR(42),
  `order(int)` VARCHAR(42),
  `list_id(int)` VARCHAR(42),
  `created_at(datetime)` VARCHAR(42),
  `updated_at(datetime)` VARCHAR(42),
  `id_list(int)` VARCHAR(42),
  PRIMARY KEY (`id_card(int)`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `HAVE_ACCESS` ADD FOREIGN KEY (`id_board(int)`) REFERENCES `BOARD` (`id_board(int)`);
ALTER TABLE `HAVE_ACCESS` ADD FOREIGN KEY (`id_user(int)`) REFERENCES `USERS` (`id_user(int)`);
ALTER TABLE `LIST` ADD FOREIGN KEY (`id_board(int)`) REFERENCES `BOARD` (`id_board(int)`);
ALTER TABLE `CARD` ADD FOREIGN KEY (`id_list(int)`) REFERENCES `LIST` (`id_list(int)`);